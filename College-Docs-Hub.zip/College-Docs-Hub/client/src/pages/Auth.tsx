import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation, useSearch } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Loader2, 
  Mail, 
  Lock, 
  User, 
  ArrowLeft,
  GraduationCap,
  ShieldCheck
} from "lucide-react";

import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// Form schemas
const loginSchema = z.object({
  username: z.string().min(1, "Email/Username is required"),
  password: z.string().min(1, "Password is required"),
});

const studentRegisterSchema = z.object({
  username: z.string().email("Must be a valid email").refine(val => val.endsWith("@anurag.ac.in"), {
    message: "Must use your college email (@anurag.ac.in)"
  }),
  password: z.string().min(6, "Password must be at least 6 characters"),
  branch: z.enum(["CSE", "ECE", "AIML", "IT", "MECH", "CIVIL"]),
});

const adminRegisterSchema = z.object({
  username: z.string().min(3, "Username/Email is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const defaultTab = params.get("tab") || "signin";
  
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [role, setRole] = useState<"student" | "admin">("student");
  const { login, register, isLoggingIn, isRegistering, user } = useAuth();

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === "admin") setLocation("/admin-dashboard");
      else setLocation("/student-dashboard");
    }
  }, [user, setLocation]);

  // Login Form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
  });

  // Student Register Form
  const studentForm = useForm<z.infer<typeof studentRegisterSchema>>({
    resolver: zodResolver(studentRegisterSchema),
    defaultValues: { branch: "CSE" }
  });

  // Admin Register Form
  const adminForm = useForm<z.infer<typeof adminRegisterSchema>>({
    resolver: zodResolver(adminRegisterSchema),
  });

  const onLogin = (data: z.infer<typeof loginSchema>) => {
    login(data);
  };

  const onRegisterStudent = (data: z.infer<typeof studentRegisterSchema>) => {
    register({ ...data, role: "student" });
  };

  const onRegisterAdmin = (data: z.infer<typeof adminRegisterSchema>) => {
    register({ ...data, role: "admin" });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-background p-4 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 z-0 opacity-40 dark:opacity-10 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md z-10"
      >
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="mb-6 hover:bg-transparent hover:text-primary pl-0"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>

        <Card className="border-border shadow-2xl backdrop-blur-xl bg-white/90 dark:bg-card/90">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-2xl font-display">Welcome Back</CardTitle>
            <CardDescription>Access your college dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="signin">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>

              <AnimatePresence mode="wait">
                <TabsContent value="signin" className="mt-0">
                  <motion.form 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    onSubmit={loginForm.handleSubmit(onLogin)} 
                    className="space-y-4"
                  >
                    <div className="space-y-2">
                      <Label htmlFor="username">Email or Username</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="username" 
                          placeholder="student@college.edu" 
                          className="pl-9"
                          {...loginForm.register("username")} 
                        />
                      </div>
                      {loginForm.formState.errors.username && (
                        <p className="text-sm text-destructive">{loginForm.formState.errors.username.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="password" 
                          type="password" 
                          placeholder="••••••••" 
                          className="pl-9"
                          {...loginForm.register("password")} 
                        />
                      </div>
                      {loginForm.formState.errors.password && (
                        <p className="text-sm text-destructive">{loginForm.formState.errors.password.message}</p>
                      )}
                    </div>

                    <Button type="submit" className="w-full" disabled={isLoggingIn}>
                      {isLoggingIn ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Sign In"}
                    </Button>
                  </motion.form>
                </TabsContent>

                <TabsContent value="signup" className="mt-0">
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div className="flex gap-4 mb-4">
                      <div 
                        onClick={() => setRole("student")}
                        className={`flex-1 p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-2 ${
                          role === "student" 
                            ? "border-primary bg-primary/5 text-primary" 
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <GraduationCap className="h-6 w-6" />
                        <span className="text-sm font-semibold">Student</span>
                      </div>
                      <div 
                        onClick={() => setRole("admin")}
                        className={`flex-1 p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col items-center gap-2 ${
                          role === "admin" 
                            ? "border-primary bg-primary/5 text-primary" 
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <ShieldCheck className="h-6 w-6" />
                        <span className="text-sm font-semibold">Admin</span>
                      </div>
                    </div>

                    {role === "student" ? (
                      <form onSubmit={studentForm.handleSubmit(onRegisterStudent)} className="space-y-4">
                        <div className="space-y-2">
                          <Label>College Email (Roll Number)</Label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input 
                              placeholder="e.g. 23c11a0451@anurag.ac.in" 
                              className="pl-9"
                              {...studentForm.register("username")} 
                            />
                          </div>
                          {studentForm.formState.errors.username && (
                            <p className="text-sm text-destructive">{studentForm.formState.errors.username.message}</p>
                          )}
                        </div>

                        <div className="space-y-2">
                          <Label>Department</Label>
                          <select 
                            className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                            {...studentForm.register("branch")}
                          >
                            <option value="CSE">CSE</option>
                            <option value="ECE">ECE</option>
                            <option value="AIML">AIML</option>
                            <option value="IT">IT</option>
                            <option value="MECH">MECH</option>
                            <option value="CIVIL">CIVIL</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <Label>Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input 
                              type="password" 
                              placeholder="Create a password" 
                              className="pl-9"
                              {...studentForm.register("password")} 
                            />
                          </div>
                          {studentForm.formState.errors.password && (
                            <p className="text-sm text-destructive">{studentForm.formState.errors.password.message}</p>
                          )}
                        </div>

                        <Button type="submit" className="w-full" disabled={isRegistering}>
                          {isRegistering ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Create Student Account"}
                        </Button>
                      </form>
                    ) : (
                      <form onSubmit={adminForm.handleSubmit(onRegisterAdmin)} className="space-y-4">
                        <div className="space-y-2">
                          <Label>Admin Email/ID</Label>
                          <div className="relative">
                            <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input 
                              placeholder="admin@college.edu" 
                              className="pl-9"
                              {...adminForm.register("username")} 
                            />
                          </div>
                          {adminForm.formState.errors.username && (
                            <p className="text-sm text-destructive">{adminForm.formState.errors.username.message}</p>
                          )}
                        </div>

                        <div className="space-y-2">
                          <Label>Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input 
                              type="password" 
                              placeholder="Create a password" 
                              className="pl-9"
                              {...adminForm.register("password")} 
                            />
                          </div>
                          {adminForm.formState.errors.password && (
                            <p className="text-sm text-destructive">{adminForm.formState.errors.password.message}</p>
                          )}
                        </div>

                        <Button type="submit" className="w-full" disabled={isRegistering}>
                          {isRegistering ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Create Admin Account"}
                        </Button>
                      </form>
                    )}
                  </motion.div>
                </TabsContent>
              </AnimatePresence>
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
