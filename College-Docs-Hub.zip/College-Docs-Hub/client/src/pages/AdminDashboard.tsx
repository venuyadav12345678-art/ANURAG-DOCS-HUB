import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { 
  LogOut, 
  Upload, 
  Plus, 
  FileText,
  Search,
  Folder,
  Info,
  Phone,
  Mail,
  MapPin,
  Layers,
  Home
} from "lucide-react";

import { useAuth } from "@/hooks/use-auth";
import { useDocuments, useCreateDocument, useDeleteDocument } from "@/hooks/use-documents";
import { DocumentCard } from "@/components/DocumentCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const uploadSchema = z.object({
  title: z.string().min(3, "Title required"),
  subject: z.string().min(2, "Subject required"),
  branch: z.enum(["CSE", "ECE", "AIML", "IT", "MECH", "CIVIL"]),
  year: z.enum(["1st Year", "2nd Year", "3rd Year", "4th Year"]),
  file: z.instanceof(File, { message: "File required" }),
});

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [filterBranch, setFilterBranch] = useState<string>("");
  const [filterYear, setFilterYear] = useState<string>("");

  const { data: documents, isLoading } = useDocuments({ 
    branch: filterBranch || undefined,
    search: search || undefined
  });
  
  const createDocument = useCreateDocument();
  const deleteDocument = useDeleteDocument();

  const form = useForm<z.infer<typeof uploadSchema>>({
    resolver: zodResolver(uploadSchema),
    defaultValues: { branch: "CSE", year: "1st Year" }
  });

  const onSubmit = async (data: z.infer<typeof uploadSchema>) => {
    const formData = new FormData();
    formData.append("file", data.file);

    try {
      const uploadRes = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!uploadRes.ok) throw new Error("Upload failed");
      const { url } = await uploadRes.json();

      createDocument.mutate({
        title: data.title,
        subject: data.subject,
        branch: data.branch,
        year: data.year,
        url,
      }, {
        onSuccess: () => {
          setIsDialogOpen(false);
          form.reset();
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const branches = ["CSE", "ECE", "AIML", "IT", "MECH", "CIVIL"];
  const years = ["1st Year", "2nd Year", "3rd Year", "4th Year"];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Background Image Overlay */}
      <div className="fixed inset-0 z-0 opacity-5 pointer-events-none">
        <img 
          src="https://anurag.ac.in/wp-content/uploads/2024/06/About-us-top.jpg" 
          alt="College Background" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Header */}
      <header className="bg-slate-900/90 text-white backdrop-blur-sm sticky top-0 z-30 shadow-md relative">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Logo" className="w-10 h-10 object-contain bg-white rounded-lg p-1" />
            <div>
              <h1 className="font-display font-bold text-xl leading-none text-accent">Anurag Engineering College</h1>
              <p className="text-xs text-slate-400 mt-1">Admin Console | {user?.username}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => logout()} 
            className="text-slate-300 hover:text-white hover:bg-white/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 flex-1 relative z-10">
        <Tabs defaultValue="home" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto h-12 items-stretch p-1 bg-muted/50 rounded-xl">
            <TabsTrigger value="home" className="rounded-lg gap-2">
              <Home className="w-4 h-4" /> Home
            </TabsTrigger>
            <TabsTrigger value="departments" className="rounded-lg gap-2">
              <Layers className="w-4 h-4" /> Departments
            </TabsTrigger>
            <TabsTrigger value="about" className="rounded-lg gap-2">
              <Info className="w-4 h-4" /> About Us
            </TabsTrigger>
            <TabsTrigger value="contact" className="rounded-lg gap-2">
              <Phone className="w-4 h-4" /> Contact Us
            </TabsTrigger>
          </TabsList>

          <TabsContent value="home" className="outline-none">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="bg-card/80 p-8 rounded-3xl border shadow-sm">
                <h2 className="text-3xl font-bold font-display mb-6">College Details</h2>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <p className="text-muted-foreground leading-relaxed">
                      Anurag Engineering College is a premier technical institution located in Anantagiri, Kodad. Established with a vision to provide quality technical education, it has grown into one of the leading engineering colleges in the region.
                    </p>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        <span>NAAC Accredited Institution</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        <span>State-of-the-art Infrastructure</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        <span>Expert Faculty & Placement Support</span>
                      </li>
                    </ul>
                  </div>
                  <div className="rounded-2xl overflow-hidden shadow-lg border">
                    <img 
                      src="https://anurag.ac.in/wp-content/uploads/2024/06/About-us-top.jpg" 
                      alt="College View" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="about" className="outline-none">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="bg-card/80 p-8 rounded-3xl border shadow-sm">
                <h2 className="text-3xl font-bold font-display mb-6 text-primary">How this Website Works</h2>
                <div className="grid md:grid-cols-2 gap-12 items-center">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary">1</div>
                        <p className="text-muted-foreground">Log in with your college-issued credentials to access the secure portal.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary">2</div>
                        <p className="text-muted-foreground">Select your Engineering Department from the "Departments" tab to view specific branch resources.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary">3</div>
                        <p className="text-muted-foreground">Browse documents organized by academic year (1st to 4th Year) for better clarity.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary">4</div>
                        <p className="text-muted-foreground">Download lecture notes, lab manuals, and previous year question papers directly.</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-primary/5 p-8 rounded-2xl border-2 border-primary/10">
                    <h3 className="text-xl font-bold mb-4">Website Features</h3>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-primary" />
                        <span>Secure Administrative Management</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <Folder className="w-5 h-5 text-primary" />
                        <span>Branch & Year-wise Organization</span>
                      </li>
                      <li className="flex items-center gap-3">
                        <Upload className="w-5 h-5 text-primary" />
                        <span>Instant Resource Distribution</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="departments" className="space-y-8 outline-none">
            {/* Actions Bar */}
            <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-card/80 p-4 rounded-2xl border shadow-sm backdrop-blur-sm">
              <div className="flex flex-wrap gap-2 w-full md:w-auto">
                 <div className="relative w-full md:w-64">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search documents..." 
                    className="pl-9 bg-background/50"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <Select value={filterBranch} onValueChange={setFilterBranch}>
                  <SelectTrigger className="w-[180px] bg-background/50">
                    <SelectValue placeholder="All Branches" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Branches</SelectItem>
                    {branches.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={filterYear} onValueChange={setFilterYear}>
                  <SelectTrigger className="w-[180px] bg-background/50">
                    <SelectValue placeholder="All Years" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Years</SelectItem>
                    {years.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full md:w-auto shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
                    <Plus className="w-4 h-4 mr-2" />
                    Upload Document
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Upload New Document</DialogTitle>
                    <DialogDescription>
                      Share resources with students. Make sure the URL is accessible.
                    </DialogDescription>
                  </DialogHeader>

                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2 col-span-2">
                        <Label>Document Title</Label>
                        <Input placeholder="e.g. Data Structures Notes Unit 1" {...form.register("title")} />
                        {form.formState.errors.title && (
                          <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Subject</Label>
                        <Input placeholder="e.g. Data Structures" {...form.register("subject")} />
                         {form.formState.errors.subject && (
                          <p className="text-sm text-destructive">{form.formState.errors.subject.message}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label>Branch</Label>
                        <Select 
                          onValueChange={(val) => form.setValue("branch", val as any)} 
                          defaultValue="CSE"
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Branch" />
                          </SelectTrigger>
                          <SelectContent>
                            {branches.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Academic Year</Label>
                        <Select 
                          onValueChange={(val) => form.setValue("year", val as any)} 
                          defaultValue="1st Year"
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Year" />
                          </SelectTrigger>
                          <SelectContent>
                            {years.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2 col-span-2">
                        <Label>Document File</Label>
                        <Input 
                          type="file" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) form.setValue("file", file);
                          }} 
                        />
                         {form.formState.errors.file && (
                          <p className="text-sm text-destructive">{form.formState.errors.file.message}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                      <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createDocument.isPending}>
                        {createDocument.isPending ? "Uploading..." : "Upload Document"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Documents Grid */}
            <div className="space-y-12">
              {branches.filter(b => !filterBranch || filterBranch === "all" || filterBranch === b).map(branch => {
                const branchDocs = documents?.filter(d => d.branch === branch && (!filterYear || filterYear === "all" || d.year === filterYear)) ?? [];
                if (branchDocs.length === 0 && filterBranch !== branch && !filterYear) return null;

                return (
                  <div key={branch} className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Folder className="w-6 h-6 text-primary" />
                      <h3 className="text-2xl font-bold">{branch} Documents</h3>
                      <div className="h-[2px] flex-1 bg-muted rounded-full ml-2" />
                    </div>
                    
                    {branchDocs.length === 0 ? (
                      <p className="text-muted-foreground italic pl-9">No documents matching filters.</p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pl-0 md:pl-9">
                        <AnimatePresence mode="popLayout">
                          {branchDocs.map((doc) => (
                            <DocumentCard 
                              key={doc.id} 
                              document={doc} 
                              isAdmin 
                              onDelete={(id) => deleteDocument.mutate(id)} 
                            />
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="contact" className="outline-none">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-4xl mx-auto grid md:grid-cols-2 gap-12 bg-card/80 p-8 rounded-3xl border shadow-sm"
            >
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold font-display mb-4">Support & Contact</h2>
                  <p className="text-muted-foreground">Administrative support contact details.</p>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Call Us</p>
                      <p className="text-lg font-bold">9014630449</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email Us</p>
                      <p className="text-lg font-bold">venuyadav0055@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Location</p>
                      <p className="text-lg font-bold">Anantagiri (V), Kodad, Telangana</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-background/50 rounded-2xl p-6 border shadow-sm">
                <h3 className="text-xl font-bold mb-6">Internal Support</h3>
                <p className="text-muted-foreground">For technical issues with the portal, contact the development team.</p>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="py-6 border-t bg-white/50 backdrop-blur-sm text-center text-sm text-muted-foreground mt-auto">
        <p>© 2026 ANURAG ENGINEERING COLLEGE. All rights reserved.</p>
      </footer>
    </div>
  );
}
