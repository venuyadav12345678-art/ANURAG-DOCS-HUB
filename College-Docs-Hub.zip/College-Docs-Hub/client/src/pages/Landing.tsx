import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, GraduationCap, ShieldCheck } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-50/50 dark:from-background dark:via-blue-950/20 dark:to-indigo-950/20 relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-4 h-screen flex flex-col items-center justify-center relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center max-w-3xl mx-auto space-y-8"
        >
            <div className="w-24 h-24 bg-white rounded-2xl shadow-xl flex items-center justify-center p-2 mx-auto mb-6">
              <img src="/logo.png" alt="College Logo" className="w-full h-full object-contain" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold font-display tracking-tight text-primary drop-shadow-sm">
              ANURAG ENGINEERING COLLEGE
            </h1>

          <p className="text-base text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Providing quality education and excellence in B.Tech programs. 
            Access your academic resources, lecture notes, and lab manuals in one place.
          </p>

          <div className="grid md:grid-cols-2 gap-6 max-w-xl mx-auto mt-12">
            <Link href="/auth?tab=signin" className="group">
              <div className="p-6 bg-white dark:bg-card border border-border/50 rounded-2xl shadow-xl hover:shadow-2xl hover:scale-[1.02] hover:border-primary/50 transition-all duration-300 cursor-pointer h-full">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-white transition-colors">
                  <GraduationCap className="w-6 h-6 text-primary group-hover:text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Student Access</h3>
                <p className="text-muted-foreground mb-4">Log in to find notes and download resources for your department.</p>
                <div className="flex items-center text-primary font-semibold group-hover:gap-2 transition-all">
                  Sign In <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            </Link>

            <Link href="/auth?tab=signup" className="group">
              <div className="p-6 bg-white dark:bg-card border border-border/50 rounded-2xl shadow-xl hover:shadow-2xl hover:scale-[1.02] hover:border-accent/50 transition-all duration-300 cursor-pointer h-full">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-accent group-hover:text-white transition-colors">
                  <ShieldCheck className="w-6 h-6 text-accent group-hover:text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">New Account</h3>
                <p className="text-muted-foreground mb-4">Create your student or administrative account to get started.</p>
                <div className="flex items-center text-accent font-semibold group-hover:gap-2 transition-all">
                  Sign Up <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

