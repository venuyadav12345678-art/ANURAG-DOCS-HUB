import { motion } from "framer-motion";
import { FileText, Download, Trash2, Calendar, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Document } from "@shared/schema";
import { format } from "date-fns";

interface DocumentCardProps {
  document: Document;
  isAdmin?: boolean;
  onDelete?: (id: number) => void;
}

export function DocumentCard({ document, isAdmin, onDelete }: DocumentCardProps) {
  // Mock download function since we don't have real file storage
  const handleDownload = () => {
    window.open(document.url, '_blank');
  };

  const branchColors: Record<string, string> = {
    CSE: "bg-blue-100 text-blue-700 hover:bg-blue-200",
    ECE: "bg-purple-100 text-purple-700 hover:bg-purple-200",
    AIML: "bg-emerald-100 text-emerald-700 hover:bg-emerald-200",
    MECH: "bg-orange-100 text-orange-700 hover:bg-orange-200",
    CIVIL: "bg-stone-100 text-stone-700 hover:bg-stone-200",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="group relative overflow-hidden bg-card hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border-border/50">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
          <FileText className="w-24 h-24 text-primary rotate-12" />
        </div>

        <div className="p-6 flex flex-col h-full relative z-10">
          <div className="flex items-start justify-between mb-4">
            <Badge 
              variant="secondary" 
              className={`font-semibold px-3 py-1 ${branchColors[document.branch] || "bg-gray-100 text-gray-700"}`}
            >
              {document.branch}
            </Badge>
            {document.uploadedAt && (
              <span className="text-xs text-muted-foreground flex items-center gap-1 bg-background/50 backdrop-blur-sm px-2 py-1 rounded-full border">
                <Calendar className="w-3 h-3" />
                {format(new Date(document.uploadedAt), "MMM d, yyyy")}
              </span>
            )}
          </div>

          <div className="flex-grow space-y-2">
            <h3 className="text-lg font-bold leading-tight font-display text-foreground group-hover:text-primary transition-colors">
              {document.title}
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <BookOpen className="w-4 h-4" />
              <span>{document.subject}</span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-border/50 flex items-center justify-between gap-3">
            <Button 
              className="flex-1 gap-2 shadow-lg shadow-primary/20 hover:shadow-primary/30"
              onClick={handleDownload}
            >
              <Download className="w-4 h-4" />
              Download
            </Button>
            
            {isAdmin && onDelete && (
              <Button 
                variant="destructive" 
                size="icon"
                onClick={() => {
                  if (window.confirm("Are you sure you want to delete this document?")) {
                    onDelete(document.id);
                  }
                }}
                className="opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
