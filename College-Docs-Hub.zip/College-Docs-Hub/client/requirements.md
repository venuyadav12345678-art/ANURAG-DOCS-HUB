## Packages
framer-motion | Complex page transitions and UI animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['"DM Sans"', "sans-serif"],
  display: ['"Outfit"', "sans-serif"],
}
