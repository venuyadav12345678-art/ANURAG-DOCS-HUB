# Anurag Engineering College Document Portal

## Overview

A responsive B.Tech college document downloading website for Anurag Engineering College. The platform enables students to browse and download academic resources (notes, lab manuals, PDFs) organized by department and year, while administrators can upload and manage documents. Features role-based authentication with separate dashboards for students and admins.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Animations**: Framer Motion for page transitions and UI animations
- **Build Tool**: Vite with custom plugins for Replit environment

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **Session Management**: express-session with connect-pg-simple for PostgreSQL session storage
- **Authentication**: Passport.js with local strategy

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Tables**:
  - `users`: Stores user credentials, roles (admin/student), and optional branch
  - `documents`: Stores document metadata (title, URL, branch, year, subject)

### Authentication Flow
- Students must register with college email format (@anurag.ac.in)
- Admins can use any email/username
- Role-based routing redirects users to appropriate dashboards
- Session-based authentication persisted in PostgreSQL

### API Structure
- RESTful endpoints defined in `shared/routes.ts` with Zod validation schemas
- Authentication endpoints: `/api/auth/login`, `/api/auth/register`, `/api/auth/logout`, `/api/auth/me`
- Document endpoints: `/api/documents` (GET, POST, DELETE)
- Type-safe API contracts shared between frontend and backend

### Project Structure
```
client/           # React frontend
  src/
    components/   # UI components including shadcn/ui
    pages/        # Route components (Landing, Auth, Dashboards)
    hooks/        # Custom hooks (useAuth, useDocuments)
    lib/          # Utilities and query client
server/           # Express backend
  auth.ts         # Passport configuration
  routes.ts       # API route handlers
  storage.ts      # Database operations
  db.ts           # Database connection
shared/           # Shared code between client/server
  schema.ts       # Drizzle database schema
  routes.ts       # API route definitions with Zod
```

## External Dependencies

### Database
- **PostgreSQL**: Primary database for users, documents, and sessions
- Connection via `DATABASE_URL` environment variable
- Drizzle Kit for migrations (`npm run db:push`)

### UI Component Library
- **shadcn/ui**: Pre-built accessible components using Radix UI primitives
- Configured in `components.json` with New York style variant
- Components located in `client/src/components/ui/`

### Key NPM Packages
- `@tanstack/react-query`: Server state management
- `drizzle-orm` / `drizzle-zod`: Database ORM and validation
- `passport` / `passport-local`: Authentication
- `framer-motion`: Animations
- `wouter`: Client-side routing
- `zod`: Schema validation

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret for session encryption (defaults to fallback in development)