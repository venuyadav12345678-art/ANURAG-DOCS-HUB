import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage_multer = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage_multer });

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth (Session + Passport)
  setupAuth(app);

  // File Upload API
  app.post("/api/upload", upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).send("No file uploaded");
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
  });

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    const filePath = path.join(uploadDir, req.path);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("File not found");
    }
  });

  // Documents API
  app.get(api.documents.list.path, async (req, res) => {
    const branch = req.query.branch as string | undefined;
    const search = req.query.search as string | undefined;
    const docs = await storage.getDocuments(branch, search);
    res.json(docs);
  });

  app.post(api.documents.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== 'admin') {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const input = api.documents.create.input.parse(req.body);
      const doc = await storage.createDocument({ ...input, uploadedBy: req.user.id });
      res.status(201).json(doc);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.documents.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== 'admin') {
      return res.status(401).send("Unauthorized");
    }

    await storage.deleteDocument(Number(req.params.id));
    res.sendStatus(204);
  });

  // Seed Data
  seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingDocs = await storage.getDocuments();
  if (existingDocs.length === 0) {
    // Create a demo admin
    const admin = await storage.getUserByUsername("admin@college.edu");
    let adminId = admin?.id;
    
    if (!admin) {
      const newAdmin = await storage.createUser({
        username: "admin@college.edu",
        password: "adminpassword",
        role: "admin",
        branch: null
      });
      adminId = newAdmin.id;
    }

    if (adminId) {
      await storage.createDocument({
        title: "Engineering Mathematics I Notes",
        url: "#",
        branch: "CSE",
        subject: "Mathematics I",
        uploadedBy: adminId
      });
      await storage.createDocument({
        title: "Data Structures Lab Manual",
        url: "#",
        branch: "CSE",
        subject: "Data Structures",
        uploadedBy: adminId
      });
      await storage.createDocument({
        title: "Circuit Theory Basics",
        url: "#",
        branch: "ECE",
        subject: "Circuit Theory",
        uploadedBy: adminId
      });
      await storage.createDocument({
        title: "Thermodynamics Overview",
        url: "#",
        branch: "MECH",
        subject: "Thermodynamics",
        uploadedBy: adminId
      });
    }
  }
}
